// get data from input box and table, then store in local storage
function saveDataToLocalStorage() {
    var tableData = [];
    for (var i = 0; i < list1.length; i++) {
        var rowData = {
            name: list1[i],
            email: list2[i],
            age: list3[i]
        };
        tableData.push(rowData);
    }
    localStorage.setItem('tableData', JSON.stringify(tableData));
}


// add button function create an array 

var list1=[];
var list2=[];
var list3=[];
var list4=[];
var n=1;
var x=0;
// then write a function
function AddRow(){
var AddRoll=document.getElementById('dataTable');
var NewRow=AddRoll.insertRow(n);

list1[x] = document.getElementById("name").value;
list2[x] = document.getElementById("email").value;
list3[x] = document.getElementById("age").value;

// new cell
var cel1=NewRow.insertCell(0);
var cel2=NewRow.insertCell(1);
var cel3=NewRow.insertCell(2);
var cel4=NewRow.insertCell(3);
// for inner html
cel1.innerHTML =list1[x];
cel2.innerHTML =list2[x];
cel3.innerHTML =list3[x];
cel4.innerHTML = '<button onclick="editRow(this.parentNode.parentNode)">Edit</button>' + 
'<button onclick="deleteRow(this.parentNode.parentNode)">Delete</button>';
saveDataToLocalStorage();

n++;
x++;


}
// edit row
function editRow(row) {
    var formData = prompt('Enter updated data (name,email,age) separated by commas:');
    if (formData) {
        var newData = formData.split(',');
        row.cells[0].textContent = newData[0];
        row.cells[1].textContent = newData[1];
        row.cells[2].textContent = newData[2];
        saveDataToLocalStorage();
    }
}
// delete row
function deleteRow(row) {
    var index = row.rowIndex - 1;
    list1.splice(index, 1);
    list2.splice(index, 1);
    list3.splice(index, 1);
    row.remove();
    saveDataToLocalStorage();
}